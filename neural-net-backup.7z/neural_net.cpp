#ifndef NEURAL_NET_H
	#include "neural_net.h"
#endif

/*
internal boolint NeuralNetInitialize (neural_net* Net, void** Memory, uint64_t* MemorySize)

internal void NeuralNetUpdate (neural_net* Net, float* SensorValues, float* MotorValues, int RewardPunish)
*/
#if 1

internal void DendriteInitialize(neural_net* Net, dendrite* Dendrite, dendrite* OtherDendrite)
{
			Dendrite->Sender = (uint64_t)((float)rand() / (float)RAND_MAX / 2.0f * (float)Net->NumOfNeurons);

			int Factor = rand() % 20 + 1;
			Dendrite->Strength = (Factor > 10 ? (float)(Factor - 10) : 1.0f / (float)Factor);
			if (rand() % 2 == 1)
			{
				Dendrite->Strength = -Dendrite->Strength;
			}
			Dendrite->Reward = 0;
			Dendrite->RewardSensitivity = 0;
			*OtherDendrite = *Dendrite;
}

internal boolint NeuralNetInitialize (neural_net* Net)
{

	Net->Toggle = 0;

	for (int NeuronIndex = 0; NeuronIndex < Net->NumOfNeurons / 2; NeuronIndex++) {
		
		neuron* Neuron = &Net->Neurons[NeuronIndex * 2 + Net->Toggle];
		neuron* OtherNeuron = &Net->Neurons[NeuronIndex * 2 + !Net->Toggle];

		Neuron->Firing = 0;

		//Dendrite Generation
		Neuron->CurrentNumDendrites = 0;
		for (int DendriteIndex = 0; DendriteIndex < Net->InitialDendrites; DendriteIndex++) {

			dendrite* Dendrite = &Neuron->Dendrites[DendriteIndex];
			dendrite* PairedDendrite = &OtherNeuron->Dendrites[DendriteIndex];

			DendriteInitialize(Net, Dendrite, PairedDendrite);
			Neuron->CurrentNumDendrites++;
		}
		*OtherNeuron = *Neuron;
	}
	return true;
}
/*
internal int32_t CheckMagnitude (int64_t TestFiring)
{
	if (TestFiring > 2147483647) {
		return 2147483647;
	}
	else if (TestFiring < -2147483648) {
		return -2147483648;
	}
	else {
		return (int32_t) TestFiring;
	}
}
*/

internal int SignOf (float Number)
{
	int Result = 0;

	if (Number < 0)
	{
		Result = -1;
	}
	else if (Number > 0)
	{
		Result = 1;
	}

	return Result;
}

internal float AbsVal (float Number)
{
	float Result = Number;
	if (Result < 0)
	{
		Result = -Result;
	}
	return Result;
}

internal void NeuralNetUpdate (neural_net* Net, float* SensorValues, float* MotorValues, float RewardPunish)
{
	//Not implemented yet:
	// dendrite creation or destruction 
	// creation or destruction of senses
	// algorithms all probably need tweaking
	for (int NeuronIndex = 0; NeuronIndex < Net->NumOfNeurons / 2; NeuronIndex++)
	{

		neuron* OldNeuron = &Net->Neurons[NeuronIndex * 2 + Net->Toggle];
		neuron* NewNeuron = &Net->Neurons[NeuronIndex * 2 + !Net->Toggle];

		float TestFiring = 0;// = (float)OldNeuron->Firing * .25f;

		for (int DendriteIndex = 0; DendriteIndex < OldNeuron->CurrentNumDendrites; DendriteIndex++)
		{
			uint64_t SenderNumber = OldNeuron->Dendrites[DendriteIndex].Sender * 2 + Net->Toggle;

			dendrite* OldDendrite = &OldNeuron->Dendrites[DendriteIndex];
			dendrite* NewDendrite = &NewNeuron->Dendrites[DendriteIndex];
			
			neuron* NeuronOfDendrite = &Net->Neurons[SenderNumber];
			TestFiring += NeuronOfDendrite->Firing * (OldDendrite->Strength + OldDendrite->Reward) * 1.0f / OldNeuron->CurrentNumDendrites;
		Assert(TestFiring == TestFiring);


		//make dendrite reward punish done through percentages - a reward of 10 means 10 percent/high reward, or suchlike. strength of a dendrite should change by percentage, not adding the rewardpunish
			float DendriteReward = OldDendrite->Reward;
			float RPSensitivity = OldDendrite->RewardSensitivity;
			
			NewDendrite->Reward = DendriteReward * .90f + .10f * (RewardPunish * RPSensitivity);

			Assert(NewDendrite->Reward == NewDendrite->Reward);
		
			float TestStrength = OldDendrite->Strength * (1.0f + .01f * DendriteReward);

			NewDendrite->RewardSensitivity = (.90f * RPSensitivity) + .10f * (TestStrength * OldNeuron->Firing);

			Assert(NewDendrite->RewardSensitivity == NewDendrite->RewardSensitivity);

			if (TestStrength > 1000.0f)
			{
				TestStrength = 1000.0f;
			}

			if (TestStrength < -1000.0f)
			{
				TestStrength = -1000.0f;
			}

			if ((TestStrength > -.001f && TestStrength < .001f) || SignOf(TestStrength) != SignOf(OldDendrite->Strength))
			{
				DendriteInitialize(Net, NewDendrite, OldDendrite);
			}
			else
			{
				NewDendrite->Strength = TestStrength;
			}
			
			Assert(NewDendrite->Strength == NewDendrite->Strength);
		}

				 
		if (TestFiring > 1.0)
		{
			TestFiring = 1.0;
		}
		if (TestFiring < -1.0)
		{
			TestFiring = -1.0;
		}
		Assert(TestFiring == TestFiring);

		if (NeuronIndex < Net->NumSensorValues)
		{
			TestFiring = (float)SensorValues[NeuronIndex] * 1.0f;
			Assert(TestFiring == TestFiring);
		}


		NewNeuron->Firing = TestFiring;

		//Change the output/motor values accordingly if necessary
		int MotorNumber = (Net->NumOfNeurons / 2 - 1) - NeuronIndex;
		if (MotorNumber < Net->NumMotorValues)
		{
			MotorValues[MotorNumber] = NewNeuron->Firing;
			Assert(MotorValues[MotorNumber] == MotorValues[MotorNumber]);
		}
		
	}
	
	Net->Toggle = !Net->Toggle;
	return;
}

#endif
