#ifndef NEURAL_NET_H

#define NUMNEURONS 100
#define NUMDENDRITES 30


/*
typedef struct dendrite
{

} dendrite;

typedef struct neuron
{
} neuron;

typedef struct neural_net
{
} neural_net;
*/



#if 1
typedef struct dendrite
{
	uint64_t Sender;
	//the neuron they receive from

	float Strength;
	//Synaptic strength of each dendrite - slowly influenced by the synaptic strength change - slight decay over time until destruction? if/when destroyed move last dendrite to its place

	float Reward;
	//Synaptic strength change based on recent re/pun, adds linearly when re/pun'ed

	float RewardSensitivity;
	//Synaptic "susceptibility" to re/pun based on recency and strength of fire - punishment slightly less effective than reinforcement - reduces based on a high-high-high-middle-low curve...
} dendrite;

typedef struct neuron
{
	
	float Firing; // the strength of current firing/negafiring - have a deadzone y/n?

	int CurrentNumDendrites; //Keep track of how many dendrites there are
	//Dendrite info
	
	dendrite Dendrites[NUMDENDRITES];
	//dendrite* FirstDendrite;

} neuron;

typedef struct neural_net
{
	int NumOfNeurons;
	int InitialDendrites;
	int MaxDendrites;
	int NumSensorValues;
	int NumMotorValues;

	boolint Toggle;
	
	neuron Neurons[NUMNEURONS];
	//neuron* Neurons;
	
	
	
	//int GoalDendrites;
	
} neural_net;

#endif
#define NEURAL_NET_H
#endif
